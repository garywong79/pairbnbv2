get '/' do
  erb :"static/index"
end