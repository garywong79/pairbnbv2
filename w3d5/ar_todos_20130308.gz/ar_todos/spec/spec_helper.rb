require 'rubygems'
require File.expand_path("../../config/application", __FILE__)
